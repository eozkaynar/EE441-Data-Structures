#include <stdio.h>

void sortArray(float *p,int size);
void printArray(float *p, int size);
