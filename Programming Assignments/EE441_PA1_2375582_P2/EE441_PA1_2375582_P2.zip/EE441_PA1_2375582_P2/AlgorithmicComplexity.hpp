

// a recursive function that takes a null-terminated string and prints it backwards
void print_backwards(char const *string);
// a function that returns the greatest common divisor of two integers.
int gcd(int n, int m);
// a function that returns the least common multiple of two integers
int lcm(int n, int m);
