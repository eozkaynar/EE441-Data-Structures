
#include <iostream>
#include "Token.hpp"
#include "TokenList.hpp"
#include <string>
#include <string.h>
#include "Node.hpp"
#include "SyntaxTree.hpp"
#include "Libs.hpp"

using namespace std;

TokenList Lexer(const string &str)
{
    Token *head = NULL;
    TokenList tokenlist;
    for(string::size_type i = 0; i < str.size(); ++i)
    {
        // Passing condition
        if(str[i]==' ')
            continue;
        else
            switch (str[i])
            {
                case '+':
                {
                    tokenlist.createTokenList(new OperatorToken(addition,type_operator));
                    break;
                }


                case '-':
                {

                    tokenlist.createTokenList(new OperatorToken(subtraction,type_operator));

                    break;
                }
                case '*':
                {
                    tokenlist.createTokenList(new OperatorToken(multiplication,type_operator));
                    break;
                }
                case '/':
                {
                    tokenlist.createTokenList(new OperatorToken(division,type_operator));

                    break;
                }
                default:
                {
                    double number = static_cast<double>(static_cast<int>(str[i] - '0'));
                    tokenlist.createTokenList(new NumberToken(number,type_number));

                }


            }
    }
    return tokenlist;
}

int main()
{
    Token *head = NULL;
    Node *p1,*p2,*p3,*p4,*p5,*p6,*p7,*p8,*p9;


    p2 = GetNumberNode(5);
    p3 = GetNumberNode(2);
    p1 = GetOperatorNode(addition,p2,p3);
    p4 = GetNumberNode(7);
    p5 = GetNumberNode(1);
    p6 = GetOperatorNode(subtraction,p4,p5);
    p7 = GetOperatorNode(multiplication,p1,p6);
    p8 = GetNumberNode(4);
    p9 = GetOperatorNode(subtraction,p7,p8);
    //c = GetTreeNode('C',e, (TreeNode<char> *)NULL);
    //a = GetTreeNode('A',b, c);
    //Preorder(p9);


/*
    Token t(type_operator);
    InsertFront(head,t);
    OperatorToken ot('+',type_operator);
    InsertFront(head,ot);
    ot.Info();
    NumberToken nt('+',type_number);
    InsertFront(head,nt);
    nt.Info();
    TokenList node(*head);
    ShowList(head);
    cout<<ot.GetOperator();
*/
    string str = "- * + 5 2 - 7 1 4";
    TokenList tlist = Lexer(str);
    //tlist.ShowList();

    SyntaxTree syntaxTree = parser(tlist);
    syntaxTree.print();

    return 0;
}
