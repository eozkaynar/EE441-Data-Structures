#ifndef TOKENLIST_HPP_INCLUDED
#define TOKENLIST_HPP_INCLUDED

#include "Token.hpp"

class TokenList
{
    private:
        Token* head;
    public:

        TokenList():head(nullptr){}
        ~TokenList() {
            ClearList();
        }

        void createTokenList(Token* tokenPtr);
        void ShowList();
        Token* DeleteFront();
        void ClearList();
        Token* GetHead() const
        {
            return head;
        }

};

Token* TokenList::DeleteFront()
{
    Token *p = head;
    if(head != NULL)
    {
        head = head->NextNode();

    }
    return p;
}


void TokenList::ClearList()
{
    Token *currPtr, *nextPtr;

	// chain through the list deleting nodes
    currPtr = head;
    while(currPtr != NULL)
    {
	// record address of next node, delete current node
        nextPtr = currPtr->NextNode();
        delete currPtr;

        // move current node forward
        currPtr = nextPtr;
    }

    // mark list as empty
    head = NULL;
}



void TokenList::createTokenList(Token* tokenPtr)
{
        Token* currPtr = head;
        if (!head) {
            head  = tokenPtr;
        } else {
            while(currPtr->NextNode()!= NULL)
                currPtr = currPtr->NextNode();
            currPtr->InsertAfter(tokenPtr);

        }
}
void TokenList::ShowList()
{
    int pos=0;
    Token *currPtr = head;
    if(currPtr==NULL)
        cout<<"the list is empty\n";
    while(currPtr!=NULL)
    {
        cout<<"current list position: "<<pos<<endl;
        if(!currPtr->GetType())
        {
            cout << "Operator Token: ";
            switch (static_cast<int>(currPtr->GetValue())) {
                case 0:
                    cout << "+"<<endl;;
                    break;
                case 1:
                    cout << "-"<<endl;;
                    break;
                case 2:
                    cout << "*"<<endl;;
                    break;
                case 3:
                    cout << "/"<<endl;;
                    break;
                }
        }
        else
        {
                cout << "Number Token: ";
                cout <<currPtr->GetValue()<<endl;
        }
        currPtr = currPtr->NextNode();
        pos++;
    }
}
/*
void ShowList(TokenList &tlist)
{
    int pos=0;
    Token *currPtr=tlist.head;
    if(currPtr==NULL)
        cout<<"the list is empty\n";
    while(currPtr!=NULL)
    {
        cout<<"current list position: "<<pos<<endl;
        if(!currPtr->GetType())
        {
            cout << "Operator Token: ";
            switch (static_cast<int>(currPtr->GetValue())) {
                case 0:
                    cout << "+"<<endl;;
                    break;
                case 1:
                    cout << "-"<<endl;;
                    break;
                case 2:
                    cout << "*"<<endl;;
                    break;
                case 3:
                    cout << "/"<<endl;;
                    break;
                }
        }
        else
        {
                cout << "Number Token: ";
                cout <<currPtr->GetValue()<<endl;
        }
        currPtr = currPtr->NextNode();
        pos++;
    }
}
*/
#endif // TOKENLIST_HPP_INCLUDED
