#ifndef LIBS_HPP_INCLUDED
#define LIBS_HPP_INCLUDED

Node* parser(Token* &currListPtr)
{
   // Token* head = tokenList;
    Operator NodeOperator;
    // Base Case
    if (currListPtr == NULL)
    {
        return nullptr;
    }
    Type type = currListPtr->GetType();
    //cout<<"Type: "<< type<<endl;
    if(!type)
    {
        Operator Op = static_cast<OperatorToken*>(currListPtr)->GetOperator();
        cout << "currListOperator: " << static_cast<OperatorToken*>(currListPtr)->GetOperator() << endl;
        switch(Op)
        {
            case 0:{
                NodeOperator = addition;
                break;}
            case 1:{
                NodeOperator = subtraction;
                break;}
            case 2:{
                NodeOperator = multiplication;
                break;}
            case 3:{
                NodeOperator = division;
                break;}
            default:
                {
                cout << "Unknown operator code: " << Op << endl;
                return nullptr;}
        }

        // Update List element if it's not nullptr
        if (currListPtr->NextNode() != nullptr)
        {
            currListPtr = currListPtr->NextNode();
            //Recursion
            Node* NodeLeft  = parser(currListPtr);
            Node* NodeRight = parser(currListPtr);
            Node* newNode = new OperatorNode(NodeOperator,NodeLeft,NodeRight);

        return newNode;
        }
        else
            return nullptr;

    }
    else
    {
        double number = static_cast<NumberToken*>(currListPtr)->GetValue();

        // Update List element
        // Update List element if it's not nullptr
        cout << "currListNumber: " << currListPtr->GetValue() << endl;
        currListPtr = currListPtr->NextNode();


        return new NumberNode(number);
    }

    return nullptr;
}

SyntaxTree parser(TokenList& tokens) {
    Token* currentToken = tokens.GetHead();
    if (!currentToken) {
        std::cerr << "Error: Empty token list." << std::endl;
        return SyntaxTree(nullptr);
    }

    return SyntaxTree(parser(currentToken));
}


#endif // LIBS_HPP_INCLUDED
