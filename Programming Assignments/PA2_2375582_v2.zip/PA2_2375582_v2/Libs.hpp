#ifndef LIBS_HPP_INCLUDED
#define LIBS_HPP_INCLUDED
#include "Node.hpp"
#include "Token.hpp"
TokenList Lexer(const string &str)

{

    Token *head = NULL;
    TokenList tokenlist;

    int i = 0;
    string s;
    while (str[i] != '\0') {
        if (str[i] != ' ')
            {
            // Append the char to the temp string.
            s += str[i];
            }
            else
            {
                if(s == "+")
                {
                    tokenlist.createTokenList(new OperatorToken(addition,type_operator));
                }
                else if(s == "-")
                {
                    tokenlist.createTokenList(new OperatorToken(subtraction,type_operator));
                }
                else if(s == "*")
                {
                    tokenlist.createTokenList(new OperatorToken(multiplication,type_operator));
                }
                else if(s == "/")
                {
                    tokenlist.createTokenList(new OperatorToken(division,type_operator));
                }
                else
                {
                    double number = stod(s);
                    tokenlist.createTokenList(new NumberToken(number,type_number));
                }
                s.clear(); //clearing s to hold the next string value
            }
            i++;
    }
    if(s == "+")
    {
        tokenlist.createTokenList(new OperatorToken(addition,type_operator));
    }
    else if(s == "-")
    {
        tokenlist.createTokenList(new OperatorToken(subtraction,type_operator));
    }
    else if(s == "*")
    {
        tokenlist.createTokenList(new OperatorToken(multiplication,type_operator));
    }
    else if(s == "/")
    {
        tokenlist.createTokenList(new OperatorToken(division,type_operator));
    }
    else
    {
        double number = stod(s);
        tokenlist.createTokenList(new NumberToken(number,type_number));
    }

    return  tokenlist;
}


Node* parser(Token* &currListPtr)
{
   // Token* head = tokenList;
    Operator NodeOperator;
    // Base Case
    if (currListPtr == NULL)
    {
        return nullptr;
    }
    Type type = currListPtr->GetType();
    if(!type)
    {
        Operator Op = static_cast<OperatorToken*>(currListPtr)->GetOperator();
        switch(Op)
        {
            case 0:
            {
                NodeOperator = addition;
                break;
            }
            case 1:
            {
                NodeOperator = subtraction;
                break;
            }
            case 2:
            {
                NodeOperator = multiplication;
                break;
            }
            case 3:
            {
                NodeOperator = division;
                break;
            }
            default:
            {
                cout << "Unknown operator code: " << Op << endl;
                return nullptr;
            }
        }

        // Update List element if it's not nullptr
        if (currListPtr->NextNode() != nullptr)
        {
            currListPtr = currListPtr->NextNode();
            //Recursion
            Node* NodeLeft  = parser(currListPtr);
            Node* NodeRight = parser(currListPtr);
            Node* newNode = new OperatorNode(NodeOperator,NodeLeft,NodeRight);

        return newNode;
        }
        else
            return nullptr;

    }
    else
    {
        double number = currListPtr->GetValue();
        // Update List element
        currListPtr = currListPtr->NextNode();
        return new NumberNode(number);
    }

    return nullptr;
}

SyntaxTree parser(TokenList& tokens) {


    Token* head = tokens.GetHead();

    if (!head) {
        return SyntaxTree(nullptr);
    }
    return SyntaxTree(parser(head));
}



#endif // LIBS_HPP_INCLUDED
