
#include <iostream>
#include "Token.hpp"
#include "TokenList.hpp"
#include <string>
#include <string.h>
#include "Node.hpp"
#include "SyntaxTree.hpp"
#include "Libs.hpp"


using namespace std;

int main()
{
    Token *head = NULL;

    string str = "- * + -5 2 - 7 1.5 47";

    TokenList tlist = Lexer(str);
    //tlist.ShowList();

    SyntaxTree syntaxTree = parser(tlist);
    syntaxTree.print();

    return 0;
}
