#ifndef SYNTAXTREE_HPP_INCLUDED
#define SYNTAXTREE_HPP_INCLUDED

#include "Node.hpp"

class SyntaxTree
{
    public:
        Node *root;
        // Constructor
        SyntaxTree(Node* r) : root(r) {}

        ~SyntaxTree() {
            delete root;
        }

        void print() const;
        void printResult() const;

};

void SyntaxTree::print()const
{
    if (root != nullptr)
        root->print();
    printResult();
}

void SyntaxTree::printResult()const
{
    if (root != nullptr)
        cout<<" = " <<root->GetValue();
}

/*
Node *GetOperatorNode(Operator item, Node *lptr = NULL,
                         Node *rptr = NULL)
{
   Node *p;

   // call new to allocated the new node
   // pass parameters lptr and rptr to the function
   p = new OperatorNode (item, lptr, rptr);

   // if insufficient memory, exit with an error message
   if (p == NULL)
   {
      cerr << "Memory allocation failure!\n";
      exit(1);
   }

   // return the pointer to the system generated memory
   return p;
}

Node *GetNumberNode(double item, Node *lptr = NULL,
                         Node *rptr = NULL)
{
   Node *p;

   // call new to allocated the new node
   // pass parameters lptr and rptr to the function
   p = new NumberNode (item, lptr, rptr);

   // if insufficient memory, exit with an error message
   if (p == NULL)
   {
      cerr << "Memory allocation failure!\n";
      exit(1);
   }

   // return the pointer to the system generated memory
   return p;
}
*/








#endif // SYNTAXTREE_HPP_INCLUDED
