#include <iostream>
#include "FizzBuzz.hpp"
int main()
{
    int input;
    input = getInput();
    FizzBuzz(input);

    return 0;
}
