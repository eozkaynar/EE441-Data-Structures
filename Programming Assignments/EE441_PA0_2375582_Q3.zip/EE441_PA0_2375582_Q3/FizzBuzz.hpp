#include <iostream>

void FizzBuzz(int endNumber);
int getInput();
